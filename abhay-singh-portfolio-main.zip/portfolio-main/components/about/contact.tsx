'use client';

import React from 'react';

import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

import { SectionHeading, SubmitBtn } from '@/components';
import { useSectionInView } from '@/hooks';
import { sendEmail } from '@/actions';

const Contact = () => {
  const { ref } = useSectionInView('Contact');
  return (
    <motion.section
      id="contact"
      ref={ref}
      className="mb-20 sm:mb-28 w-[min(100%,38rem)] text-center scroll-mt-28"
      initial={{
        opacity: 0,
      }}
      whileInView={{
        opacity: 1,
      }}
      transition={{
        duration: 1,
      }}
      viewport={{
        once: true,
      }}
    >
      <SectionHeading>Contact Me</SectionHeading>

      <p className="text-gray-700 -mt-6 dark:text-white/80">
        Please reach out to me directly at{' '}
        <a className="underline" href="mailto:abhay5349singh@gmail.com">
          abhay5349singh@gmail.com
        </a>{' '}
        or through this form.
      </p>

      <form
        className="mt-10 flex flex-col dark:text-black"
        // isntaed of using HandleSubmit utilizing server actions
        action={async (formData) => {
          console.log(formData.get('senderEmail'));
          const { data, error } = await sendEmail(formData);
          console.log('Email data: ', data);
          if (error) {
            toast.error(error);
            return;
          }

          toast.success('Email sent successfully!');
        }}
      >
        <input
          className="h-14 px-4 rounded-lg borderBlack dark:bg-white dark:bg-opacity-80 dark:focus:bg-opacity-100 transition-all dark:outline-none"
          name="senderEmail"
          type="email"
          required
          maxLength={500}
          placeholder="Your email"
        />
        <textarea
          className="h-52 my-3 rounded-lg borderBlack p-4 dark:bg-white dark:bg-opacity-80 dark:focus:bg-opacity-100 transition-all dark:outline-none"
          name="message"
          placeholder="Your message"
          required
          maxLength={5000}
        />
        <SubmitBtn />
      </form>
    </motion.section>
  );
};

export default Contact;
